# aiaf
# AIAF - AI Agent Firewall 🚀 AIAF is a security layer that prevents prompt injection and adversarial attacks on AI chatbots.  ## Install ```sh pip install aiaf
